// 1. Imports
const express = require('express');
const pool = require('./db');
const { Client } = require('@opensearch-project/opensearch');

const app = express();
const cors = require('cors');
app.use(cors());


// 2. OpenSearch client (keep this near top)
const searchClient = new Client({
  node: 'http://localhost:9200',
  auth: {
    username: 'admin',
    password: 'OpenSearch@2026!'
  },
  ssl: {
    rejectUnauthorized: false
  }
});


// 3. Basic APIs
app.get('/restaurants', async (req, res) => {
  const result = await pool.query('SELECT * FROM restaurant');
  res.json(result.rows);
});

app.get('/menu', async (req, res) => {
  const result = await pool.query('SELECT * FROM menu');
  res.json(result.rows);
});


// 4. Aggregated API (VERY IMPORTANT)
app.get('/full-data', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        r.resid,
        r.name,
        r.address,
        r.lat,
        r.lon,
        COALESCE(
          json_agg(
            json_build_object(
              'title', m.title,
              'category', m.category,
              'price', m.price
            )
          ) FILTER (WHERE m.title IS NOT NULL),
          '[]'
        ) AS menu
      FROM restaurant r
      LEFT JOIN menu m ON r.resid = m.hotelid
      GROUP BY r.resid;
    `);

    const formatted = result.rows.map(r => ({
      resId: r.resid,
      name: r.name,
      address: r.address,
      location: {
        lat: r.lat,
        lon: r.lon
      },
      menu: r.menu || []
    }));

    res.json(formatted);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching data');
  }
});


// 5. Search API
app.get('/search', async (req, res) => {
  try {
    const { q, lat, lon } = req.query;
    console.log("LAT:", lat, "LON:", lon);

    const result = await searchClient.search({
      index: 'restaurants',
      body: {
        query: {
          bool: {
            should: [
              {
                match: {
                  name: {
                    query: q,
                    fuzziness: 'AUTO'
                  }
                }
              },
              {
                nested: {
                  path: 'menu',
                  query: {
                    match: {
                      'menu.title': {
                        query: q,
                        fuzziness: 'AUTO'
                      }
                    }
                  }
                }
              }
            ]
          }
        },
        sort: [
          {
            _geo_distance: {
              location: {
                lat: parseFloat(lat),
                lon: parseFloat(lon)
              },
              order: 'asc'
            }
          }
        ]
      }
    });

    res.json(result.body.hits.hits);
  } catch (err) {
    console.error(err);
    res.status(500).send('Search error');
  }
});


// 6. Start server (ALWAYS LAST)
app.listen(3000, () => {
  console.log('Server running on port 3000');
});