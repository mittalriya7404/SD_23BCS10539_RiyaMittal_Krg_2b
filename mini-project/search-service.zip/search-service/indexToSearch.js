const { Client } = require('@opensearch-project/opensearch');
const axios = require('axios');

const client = new Client({
  node: 'http://localhost:9200',
  auth: {
    username: 'admin',
    password: 'OpenSearch@2026!'
  },
  ssl: {
    rejectUnauthorized: false
  }
});

async function indexData() {
  try {
    const response = await axios.get('http://localhost:3000/full-data');
    const data = response.data;

    for (let item of data) {
      await client.index({
        index: 'restaurants',
        id: item.resId,
        body: item
      });
    }

    console.log('Data indexed successfully');
  } catch (err) {
    console.error(err);
  }
}

indexData();