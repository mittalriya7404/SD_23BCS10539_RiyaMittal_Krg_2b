const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'zomato_search;',
  password: 'reet123',
  port: 5432,
});

module.exports = pool;